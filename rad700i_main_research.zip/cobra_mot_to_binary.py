#!/usr/bin/env python3
"""Convert RAD 700i M-series Motorola S-record to a 1 MiB code-flash image.

This is for static disassembly, not a flashable firmware image.
"""
import sys
from pathlib import Path

BASE = 0xFFF00000
SIZE = 0x100000

def main(source, destination):
    image=bytearray(b'\xff'*SIZE)
    records=0
    for line in source.read_text().splitlines():
        if not line.startswith('S3'):
            continue
        packet=bytes.fromhex(line[2:])
        if (sum(packet)&255)!=255:
            raise ValueError(f'Invalid S-record checksum at record {records}')
        addr=int.from_bytes(packet[1:5],'big')
        data=packet[5:-1]
        if BASE <= addr and addr+len(data)<=BASE+SIZE:
            image[addr-BASE:addr-BASE+len(data)]=data
        records+=1
    destination.write_bytes(image)
    reset=int.from_bytes(image[-4:],'little')
    print(f'{records} valid S3 records, flash image {SIZE} bytes, RX reset vector 0x{reset:08x}')
    print('CAUTION: static-analysis dump; do not flash this BIN to the RAD 700i')

if __name__ == '__main__':
    if len(sys.argv)!=3:sys.exit('Usage: python cobra_mot_to_binary.py input.mot output.bin')
    main(Path(sys.argv[1]),Path(sys.argv[2]))
